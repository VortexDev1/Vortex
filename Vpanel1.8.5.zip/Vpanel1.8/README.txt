
first go to blockman go and search for "sky pixel" and join it and exit


and Go to this path:/storage/emulated/0/Android/data/com.sandboxol.blockymods/files/Download/SandboxOL/BlockManv2/map_temp/g20151633/


and when u go to the path above, unzip the file and add all files inside the zip file in the path above 


and rejoin sky pixel and join any game u want 